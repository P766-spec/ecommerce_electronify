import { useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Button, Card, Col, Row, Image, ListGroup } from "react-bootstrap";
import { CartState } from "../context/Context";
import Rating from "./Rating";
import products from "../db/Data"; // Import products data

const SingleProductDetails = () => {
  const { id } = useParams();
  const {
    state: { cart },
    dispatch,
  } = CartState();
  const [prod, setProd] = useState(null);
  const history = useHistory();

  useEffect(() => {
    const fetchProduct = async () => {
      const product = products.find((p) => p.id === id);
      setProd(product);
    };

    fetchProduct();
  }, [id]);

  if (!prod) {
    return <div>Loading...</div>;
  }

  return (
    <div className="singleProductDetails">
      <Row>
        <Col md={6}>
          <Image src={prod.image} alt={prod.name} fluid />
        </Col>
        <Col md={6}>
          <Card>
            <Card.Body style={{ padding: 20 }}>
              <div className="product-info">
                <h2 className="product-title">{prod.name}</h2>
                <p className="product-price">₹ {prod.price}</p>
                <Rating rating={prod.ratings} />
                <p className="product-description">{prod.description}</p>
                <p className="product-delivery">
                  {prod.fastDelivery ? "Fast Delivery" : "4 days delivery"}
                </p>
              </div>
              <div className="brand-info">
                <span className="brand-label">Brand:</span> {prod.brand}
              </div>

              {cart.some((p) => p.id === prod.id) ? (
                <Button
                  variant="danger"
                  onClick={() =>
                    dispatch({
                      type: "REMOVE_FROM_CART",
                      payload: prod,
                    })
                  }
                >
                  Remove from Cart
                </Button>
              ) : (
                <Button
                  onClick={() =>
                    dispatch({
                      type: "ADD_TO_CART",
                      payload: prod,
                    })
                  }
                  disabled={!prod.inStock}
                >
                  {!prod.inStock ? "Out of Stock" : "Add to Cart"}
                </Button>
              )}
              <Button
                variant="secondary"
                className="back-button"
                onClick={() => history.push("/")}
              >
                Back
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default SingleProductDetails;
