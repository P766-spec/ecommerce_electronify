import { Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import { CartState } from "../context/Context";
import Rating from "./Rating";

const SingleProduct = ({ prod }) => {
  const {
    state: { cart },
    dispatch,
  } = CartState();

  return (
    <div className="products">
      <Link to={`/product/${prod.id}`} style={{ textDecoration: "none" }}>
        <Card>
          <Card.Img
            variant="top"
            src={prod.image}
            alt={prod.name}
            style={{ padding: 50 }}
          />
          <Card.Body style={{ paddingBottom: 10 }}>
            <Card.Title>{prod.name}</Card.Title>
            <Card.Subtitle style={{ paddingBottom: 30 }}>
              <span>₹ {prod.price.split(".")[0]}</span>
              {prod.fastDelivery ? (
                <div>Fast Delivery</div>
              ) : (
                <div>4 days delivery</div>
              )}
              <Rating rating={prod.ratings} />
            </Card.Subtitle>
          </Card.Body>
        </Card>
      </Link>
      {cart.some((p) => p.id === prod.id) ? (
        <Button
          variant="danger"
          onClick={() =>
            dispatch({
              type: "REMOVE_FROM_CART",
              payload: prod,
            })
          }
        >
          Remove from Cart
        </Button>
      ) : (
        <Button
          onClick={() =>
            dispatch({
              type: "ADD_TO_CART",
              payload: prod,
            })
          }
          disabled={!prod.inStock}
        >
          {!prod.inStock ? "Out of Stock" : "Add to Cart"}
        </Button>
      )}
    </div>
  );
};

export default SingleProduct;
