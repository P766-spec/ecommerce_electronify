import React from "react";

const Dashboard = () => {
  // Sample order data
  const sampleOrder = {
    id: 12345,
    date: "2024-11-29",
    totalAmount: 29790,
    items: [
      { name: "Apple MacBook Pro", quantity: 1 },
      // ... other items
    ],
  };

  const handleDownloadInvoice = () => {
    // Generate and download fake invoice
    const invoiceData = `
      Order ID: ${sampleOrder.id}
      Date: ${sampleOrder.date}
      Total: ₹${sampleOrder.totalAmount}
      Items: 
      ${sampleOrder.items
        .map((item) => `${item.name} x ${item.quantity}`)
        .join("\n")}
    `;

    const blob = new Blob([invoiceData], { type: "text/plain" });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `invoice_${sampleOrder.id}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div>
      <h2>Dashboard</h2>
      <div>
        <h3>Recent Order</h3>
        <p>Order ID: {sampleOrder.id}</p>
        <p>Date: {sampleOrder.date}</p>
        <p>Total: ₹{sampleOrder.totalAmount}</p>
        {/* Display order items */}
        <p>Items:</p>
        <ul>
          {sampleOrder.items.map((item) => (
            <li key={item.name}>
              {item.name} x {item.quantity}
            </li>
          ))}
        </ul>
        <button onClick={handleDownloadInvoice}>Download Invoice</button>
      </div>
    </div>
  );
};

export default Dashboard;
