// import "./App.css";
// import Header from "./components/Header";
// import { BrowserRouter, Route } from "react-router-dom";
// import Home from "./components/Home";
// import Cart from "./components/Cart";
// import Footer from "./components/Footer";
// import SingleProductDetails from "./components/SingleProductDetails";

// function App() {
//   return (
//     // <BrowserRouter>
//     //   <Header />
//     //   <div className="App">
//     //     <Route path="/" exact>
//     //       <Home />
//     //     </Route>
//     //     <Route path="/cart">
//     //       <Cart />
//     //     </Route>
//     //     <Route path="/product/:id">
//     //       <SingleProductDetails />
//     //     </Route>
//     //   </div>
//     //   <Footer />
//     // </BrowserRouter>
//     <BrowserRouter>
//       <Header />
//       <div style={{ minHeight: "100vh" }}>
//         <Route path="/" exact>
//           <Home />
//         </Route>
//         <Route path="/cart">
//           <Cart />
//         </Route>
//         <Route path="/product/:id">
//           <SingleProductDetails />
//         </Route>
//       </div>
//       <Footer />
//     </BrowserRouter>
//   );
// }

// export default App;

import "./App.css";
import Header from "./components/Header";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Home from "./components/Home";
import Cart from "./components/Cart";
import Footer from "./components/Footer";
import SingleProductDetails from "./components/SingleProductDetails";
import Dashboard from "./components/Dashboard";

function App() {
  return (
    <BrowserRouter>
      <Header />
      <div style={{ minHeight: "100vh" }}>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/cart" component={Cart} />
          <Route path="/product/:id" component={SingleProductDetails} />
          <Route path="/dashboard" component={Dashboard} />
        </Switch>
      </div>
      <Footer />
    </BrowserRouter>
  );
}

export default App;
