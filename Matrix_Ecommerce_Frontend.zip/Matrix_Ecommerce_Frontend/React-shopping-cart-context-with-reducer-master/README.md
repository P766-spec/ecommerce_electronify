# Shopping Cart Built in React JS with Context API and useReducer

### Live Demo - https://shopping-cart-with-reactjs.netlify.app/
## [Watch Full Tutorial on Roadside Coder Channel](https://www.youtube.com/roadsidecoder)

![SHOPPING CART](https://user-images.githubusercontent.com/51760520/137257892-5bc9526b-4c59-4054-b255-337dc2c90123.png)
