const products = [
  {
    id: "1",
    name: "Dell 15 Thin & Light Laptop",
    price: "50,990",
    image:
      "https://m.media-amazon.com/images/I/41IMroAyzVL._SX300_SY300_QL70_FMwebp_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "2",
    name: "DELL Refurbished Latitude",
    price: "32,430",
    image:
      "https://m.media-amazon.com/images/I/61SCc8dH-8L._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 10,
    fastDelivery: false,
    ratings: 3,
    category: "Laptops",
  },
  {
    id: "3",
    name: "Dell Latitude E7470",
    price: "15,999",
    image:
      "https://m.media-amazon.com/images/I/61+D1Kn+hCL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 0,
    fastDelivery: true,
    ratings: 5,
    category: "Laptops",
  },
  {
    id: "4",
    name: "Dell Inspiron 3530",
    price: "68,790 ",
    image:
      "https://m.media-amazon.com/images/I/71kQxWE4ZHL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 8,
    fastDelivery: false,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "5",
    name: "Apple Mackbook Air",
    price: "56,990",
    image:
      "https://m.media-amazon.com/images/I/71jG+e7roXL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 2,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "6",
    name: "2022 Apple Mackbook Air",
    price: "94,990",
    image:
      "https://m.media-amazon.com/images/I/41WLV5o25tL._SY445_SX342_QL70_FMwebp_.jpg",
    inStock: 3,
    fastDelivery: false,
    ratings: 5,
    category: "Laptops",
  },
  {
    id: "7",
    name: "Apple MacBook Pro",
    price: "2,97,990",
    image:
      "https://m.media-amazon.com/images/I/61eA9PkZ07L._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 4,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "8",
    name: "Apple MacBook Air",
    price: "1599.99",
    image:
      "https://m.media-amazon.com/images/I/71duqJdFGOL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 6,
    fastDelivery: true,
    ratings: 3,
    category: "Laptops",
  },
  {
    id: "9",
    name: "Acer Aspire",
    price: "37,750",
    image:
      "https://m.media-amazon.com/images/I/51KL3aOZ0tL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 10,
    fastDelivery: false,
    ratings: 5,
    category: "Laptops",
  },
  {
    id: "10",
    name: "Acer Aspire Lite",
    price: "49,990",
    image:
      "https://m.media-amazon.com/images/I/517m2WrmJxL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "11",
    name: "Acer Nitro V",
    price: "89,990",
    image:
      "https://m.media-amazon.com/images/I/51GGNToj7aL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "12",
    name: "Acer Nitro V 16",
    price: "1,09,990",
    image:
      "https://m.media-amazon.com/images/I/51qaPeW62BL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },

  {
    id: "13",
    name: "ASUS Vivobook 16",
    price: "52,990",
    image:
      "https://m.media-amazon.com/images/I/61fsBFww9DL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "14",
    name: "ASUS Vivobook 16X",
    price: "70,990",
    image:
      "https://m.media-amazon.com/images/I/71SRRF9Wx1L._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "15",
    name: "ASUS TUF Gaming A15",
    price: "71,990",
    image:
      "https://m.media-amazon.com/images/I/61nTNphSBvL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "16",
    name: "ASUS Vivobook Go 15",
    price: "32,990",
    image:
      "https://m.media-amazon.com/images/I/71GbvoTwsQL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Laptops",
  },
  {
    id: "17",
    name: "Samsung Galaxy A35",
    price: "27,999",
    image:
      "https://m.media-amazon.com/images/I/71MBDTglV4L._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Phones",
  },
  {
    id: "18",
    name: "Samsung Galaxy S23 Ultra",
    price: "72,999",
    image:
      "https://m.media-amazon.com/images/I/71lD7eGdW-L._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Phones",
  },
  {
    id: "19",
    name: "Samsung Galaxy M33",
    price: "17,790",
    image:
      "https://m.media-amazon.com/images/I/81I3w4J6yjL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Phones",
  },
  {
    id: "20",
    name: "Samsung Galaxy S24 Ultra",
    price: "1,11,999",
    image:
      "https://m.media-amazon.com/images/I/81vxWpPpgNL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Phones",
  },
  {
    id: "21",
    name: "Apple iPhone 16",
    price: "87,900",
    image:
      "https://m.media-amazon.com/images/I/615O-NFQKdL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Phones",
  },
  {
    id: "22",
    name: "Apple iPhone 15 Plus",
    price: "69,900",
    image:
      "https://m.media-amazon.com/images/I/71PjpS59XLL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Phones",
  },
  {
    id: "23",
    name: "Apple iPhone 16 Pro Max",
    price: "1,42,900",
    image:
      "https://m.media-amazon.com/images/I/61giwQtR1qL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Phones",
  },
  {
    id: "24",
    name: "Apple iPhone 16 Pro Max 1TB",
    price: "1,84,900",
    image:
      "https://m.media-amazon.com/images/I/61PBLEFPoKL._AC_UY327_FMwebp_QL65_.jpg",
    inStock: 5,
    fastDelivery: true,
    ratings: 4,
    category: "Phones",
  },
];

export default products;
